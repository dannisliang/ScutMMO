using System;

public class SocketPackage : NetPackage
{

    public int MsgId{set;get;}

    public bool HasLoading{set;get;}

    public DateTime SendTime{set;get;}
}
