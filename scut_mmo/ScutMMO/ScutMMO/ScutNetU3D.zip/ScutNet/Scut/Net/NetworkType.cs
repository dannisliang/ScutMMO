public enum NetworkType
{
    Http = 0,
    Socket = 1,
}