﻿using UnityEngine;
using System;
using System.Collections;
using NetBase;
using System.Diagnostics;
using System.Text;
using ProtoBuf;

public enum SCUT_LOGIN_STATE
{
    LOGIN_STATE_NULL,
    LOGIN_STATE_CONNECT_SERVER,         // 连接登录服务器
    LOGIN_STATE_SERVER_LOGIN,           // 发送玩家账号，等待验证中
    LOGIN_STATE_SUCESS,                 // login server 返回验证成功，开始连接 logic server
    LOGIN_STATE_FAIL                    // 登录失败
};

public class ScutLoginProcessor : ISingleton<ScutLoginProcessor>, IModule
{
    private SCUT_LOGIN_STATE m_loginState = SCUT_LOGIN_STATE.LOGIN_STATE_NULL;

    private string user = "";
    private string pwd = "";

    private string m_logicIP = "";
    private uint m_logicPort = 0;
    private string m_logicToken = "";
    private uint m_groupId = 0;

    public string LogicIP
    {
        get { return m_logicIP; }
    }

    public uint LogicPort
    {
        get { return m_logicPort; }
    }

    public string LogicToken
    {
        get { return m_logicToken; }
    }

    public uint GroupId
    {
        get { return m_groupId; }
    }

    public bool Init()
    {
        m_loginState = SCUT_LOGIN_STATE.LOGIN_STATE_NULL;
        return true;
    }

    public bool UnInit()
    {
        return true;
    }

    public void Update()
    {
        if (m_loginState == SCUT_LOGIN_STATE.LOGIN_STATE_NULL || m_loginState == SCUT_LOGIN_STATE.LOGIN_STATE_FAIL)
        {
            return;
        }
        else if (m_loginState == SCUT_LOGIN_STATE.LOGIN_STATE_CONNECT_SERVER)
        {
            ConnectLoginServer();
            AccountRegister();
            m_loginState = SCUT_LOGIN_STATE.LOGIN_STATE_FAIL;
        }
    }

    public void Login()
    {
        m_loginState = SCUT_LOGIN_STATE.LOGIN_STATE_CONNECT_SERVER;
    }

    public void SetLoginState(SCUT_LOGIN_STATE loginState)
    {
        m_loginState = loginState;
    }

    public SCUT_LOGIN_STATE GetLoginState()
    {
        return m_loginState;
    }

    public void LogoutReset()
    {
    }

    public bool ConnectLoginServer()
    {
        NetWriter.SetUrl("192.168.1.58:9001");
        Net.Instance.Send((int)ActionType.Hello, HelloCallback, null);
        return true;
    }

    private void HelloCallback(ActionResult actionResult)
    {
        if (actionResult != null)
        {
            UnityEngine.Debug.Log("hello ok!");
        }
    }

    private bool AccountRegister()
    {
        Net.Instance.Send((int)ActionType.Regist, RegistCallback, null);
        return true;
    }

    private void RegistCallback(ActionResult actionResult)
    {
        if (actionResult != null)
        {
            ResponseRegister1002Pack responePack = actionResult.GetValue<ResponseRegister1002Pack>();
            user = responePack.passport;
            pwd = responePack.password;

            AccountLogin();
        }
    }

    private bool AccountLogin()
    {
        GameSetting.Instance.Pid = user;
        GameSetting.Instance.Password = pwd;
        Net.Instance.Send((int)ActionType.Login, LoginCallback, null);
        return true;
    }

    private void LoginCallback(ActionResult actionResult)
    {
        if (actionResult != null)
        {
            m_logicIP = "192.168.1.58";
            m_logicPort = "9001";
            m_logicToken = actionResult.Get<string>("");
            m_loginState = SCUT_LOGIN_STATE.LOGIN_STATE_SERVER_LOGIN;
        }
        else
        {
            m_loginState = SCUT_LOGIN_STATE.LOGIN_STATE_FAIL;
        }
    }
}

