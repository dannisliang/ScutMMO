﻿using System;
using System.Collections.Generic;

public class ActionResult : ActionParam
{
    public ActionResult()
    {
    }

    public ActionResult(object value)
        : base(value)
    {
    }

}
