﻿using System;
using System.Collections.Generic;

using ZyGames.Framework.Common.Serialization;
using ProtoBuf;
using UnityEngine;

public class Action1001 : BaseAction//GameAction
{
    private ResponseHello1001Pack _responseData;

    public Action1001()
        : base((int)ActionType.Hello)
    {
    }

    protected override void SendParameter(NetWriter writer, ActionParam actionParam)
    {
        RequestHello1001Pack requestPack = new RequestHello1001Pack(); ;
        byte[] data = ProtoBufUtils.Serialize(requestPack);
        writer.SetBodyData(data);
    }

    protected override void DecodePackage(NetReader reader)
    {
        if (reader != null && reader.StatusCode == 0)
        {
            //自定对象格式解包
            _responseData = ProtoBufUtils.Deserialize<ResponseHello1001Pack>(reader.Buffer);
            if (_responseData == null)
            {
                return;
            }
        }
    }

    public override ActionResult GetResponseData()
    {
        return new ActionResult(_responseData);
    }
}

