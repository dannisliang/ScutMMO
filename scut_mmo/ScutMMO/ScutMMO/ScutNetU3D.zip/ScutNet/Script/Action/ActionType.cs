﻿using System;

public enum ActionType
{
    Hello = 1001,
    Regist = 1002,
    Login = 1004,
    CreateRote = 1005,
    World = 1008
}
