﻿using System;
using System.Collections.Generic;

using ZyGames.Framework.Common.Serialization;
using ProtoBuf;
using UnityEngine;

public class Action1002 : BaseAction
{
    private ResponseRegister1002Pack _responseData;
    public Action1002()
        : base((int)ActionType.Regist)
    {
    }

    protected override void SendParameter(NetWriter writer, ActionParam actionParam)
    {
        //TODO:登录服务器获取账号
        //writer.writeString("Handler", "Passport");
        //writer.writeString("IMEI", GameSetting.Instance.DeviceID);
        RequestRegister1002Pack requestPack = new RequestRegister1002Pack();

        GameSetting.Instance.DeviceID = GlobalSettings.LoginDefaultAccount;

        requestPack.MobileType = GameSetting.Instance.MobileType;
        requestPack.GameID = GameSetting.Instance.GameID;
        requestPack.RetailID = GameSetting.Instance.RetailID;
        requestPack.ClientAppVersion = GameSetting.Instance.ClientAppVersion;
        requestPack.ScreenX = GameSetting.Instance.ScreenX;
        requestPack.ScreenY = GameSetting.Instance.ScreenY;
        requestPack.DeviceID = GameSetting.Instance.DeviceID;
        //requestPack.ServerID =  GameSetting.Instance.ServerID;

        byte[] data = ProtoBufUtils.Serialize(requestPack);
        writer.SetBodyData(data);
    }

    protected override void DecodePackage(NetReader reader)
    {
        if (reader != null && reader.StatusCode == 0)
        {
            //自定对象格式解包
            _responseData = ProtoBufUtils.Deserialize<ResponseRegister1002Pack>(reader.Buffer);
            if (_responseData == null)
            {
                return;
            }
        }
    }

    public override ActionResult GetResponseData()
    {
        return new ActionResult(_responseData);
    }
}
